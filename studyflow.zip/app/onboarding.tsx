import React from 'react';
import { View } from 'react-native';
import { useRouter } from 'expo-router';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { AppText, Button, Mascot } from '@/components/ui';
import { useApp } from '@/features/store';

export default function Onboarding() {
  const { t, colors, updateSettings } = useApp(); const router = useRouter(); const insets = useSafeAreaInsets();
  const done = () => { updateSettings({ onboarded: true }); router.replace('/'); };
  return <View style={{ flex: 1, backgroundColor: colors.background, alignItems: 'center', justifyContent: 'center', padding: 24, paddingTop: insets.top + 24, paddingBottom: insets.bottom + 24, gap: 16 }}>
    <Mascot name="reading" size={220} />
    <AppText size={36} weight="bold" color={colors.primary}>StudyFlow</AppText>
    <AppText weight="medium" style={{ textAlign: 'center' }}>{t('tagline')}</AppText>
    <AppText color={colors.muted} style={{ textAlign: 'center' }}>{t('intro')}</AppText>
    <Button title={t('getStarted')} onPress={done} style={{ alignSelf: 'stretch', marginTop: 16 }} />
    <Button title={t('skip')} variant="ghost" onPress={done} />
  </View>;
}
